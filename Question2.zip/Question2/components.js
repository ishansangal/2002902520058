
import React, { useEffect, useState } from "react";
import axios from "axios";
import moment from "moment";
import TrainItem from "./TrainItem";

const TrainSchedule = () => {
  const [scheduleData, setScheduleData] = useState([]);

  useEffect(() => {

    axios.get("/path/to/trainScheduleData.json").then((response) => {
      setScheduleData(response.data);
    });
  }, []);

  return (
    <div>
      <h1>Train Schedule</h1>
      <div className="train-schedule">
        {scheduleData.map((train) => (
          <TrainItem key={train.trainNumber} train={train} />
        ))}
      </div>
    </div>
  );
};

export default TrainSchedule;
