
import React from "react";

const TrainItem = ({ train }) => {
  return (
    <div className="train-item">
      <span>{train.trainNumber}</span>
      <span>{train.departureTime}</span>
      <span>{train.destination}</span>
      <span>{train.status}</span>
    </div>
  );
};

export default TrainItem;
