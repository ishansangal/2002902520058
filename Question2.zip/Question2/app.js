
import React from "react";
import TrainSchedule from "./components/TrainSchedule";
import "./App.css";

function App() {
  return (
    <div className="App">
      <TrainSchedule />
    </div>
  );
}

export default App;
