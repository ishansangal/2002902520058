const express = require("express");
const axios = require("axios");

const app = express();
const PORT = 8008;

app.use(express.json());

function is_valid_url(url) {
  // Simple validation to check if the URL is syntactically valid.
  return url.startsWith("http://localhost:8008/numbers?url=http://20.244.56.144/numbers/primes=http://20.244.56.144/numbers/fibo=http://20.244.56.144/numbers/odd=http://20.244.56.144/numbers/rand") || url.startsWith("http://localhost:8008/numbers?url=http://20.244.56.144/numbers/primes=http://20.244.56.144/numbers/fibo=http://20.244.56.144/numbers/odd=http://20.244.56.144/numbers/rand");
}

async function fetch_data(url) {
  try {
    const response = await axios.get(url);
    if (response.status === 200) {
      return response.data;
    } else {
      return null;
    }
  } catch (error) {
    return null;
  }
}

function extract_numbers(data) {
  // Assuming the JSON data has a key named "numbers" which contains a list of numbers.
  if (data && data.numbers && Array.isArray(data.numbers)) {
    return data.numbers;
  }
  return [];
}

app.get("/numbers", async (req, res) => {
  const { url } = req.query;
  if (!url || !Array.isArray(url)) {
    return res.status(400).json({ error: "Invalid URL parameter" });
  }

  const result = [];

  for (const u of url) {
    if (is_valid_url(u)) {
      const data = await fetch_data(u);
      if (data) {
        const numbers = extract_numbers(data);
        result.push(...numbers);
      }
    }
  }

  return res.json(result);
});

app.listen(PORT, () => {
  console.log(`Number Management Microservice running on port ${PORT}`);
});
